package com.example.locationtrackingwithintent;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import java.security.PrivateKey;

public class MainActivity extends AppCompatActivity {
    private EditText source, destination;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        source = findViewById(R.id.source);
        destination = findViewById(R.id.destination);
    }

    public void trace(View v){
        Uri uri = Uri.parse("https://www.google.co.in/maps/dir/"+
                                    source.getText().toString().trim()+"/"+
                                    destination.getText().toString().trim());
        Intent in = new Intent(Intent.ACTION_VIEW, uri);
        in.setPackage("com.google.android.apps.maps");
        startActivity(in);
    }
}