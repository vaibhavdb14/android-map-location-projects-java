package com.example.currentlocationlatlang;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements LocationListener {
    TextView txtShow;
    LocationManager locationManager;
    @SuppressLint({"MissingInflatedId", "ServiceCast", "MissingPermission"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txtShow = findViewById(R.id.latlang);
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER,0,0, this);

    }

    @Override
    public void onLocationChanged(@NonNull Location location) {
        txtShow.setText("Latitude: "+location.getLatitude()+"\n"+"Longitude: "+location.getLongitude());
    }
}